﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace BABU.Models
{
    public class ImageData
    {
     
        public string Filename { get; set; }
        public string Image { get; set; }

    }
}
